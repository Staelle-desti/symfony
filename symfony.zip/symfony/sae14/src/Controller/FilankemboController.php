<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class FilankemboController extends AbstractController
{
    #[Route('/filankembo', name: 'app_filankembo')]
    public function index(): Response
    {
        return $this->render('filankembo/index.html.twig', [
            'controller_name' => 'FilankemboController',
        ]);
    }
}
